package ru.mugalimov.volthome.domain.model

data class DefaultRoom(
    val id: Long,
    val name: String,
    val icon: String,
    val description: String,
    val roomType: RoomType
)
