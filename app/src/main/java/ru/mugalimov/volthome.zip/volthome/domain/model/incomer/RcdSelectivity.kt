package ru.mugalimov.volthome.domain.model.incomer

enum class RcdSelectivity { NONE, S }