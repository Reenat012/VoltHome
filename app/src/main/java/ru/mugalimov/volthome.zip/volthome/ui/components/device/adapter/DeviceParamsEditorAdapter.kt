package ru.mugalimov.volthome.ui.components.device.adapter

import androidx.compose.runtime.Composable

interface DeviceParamsEditorAdapter<K> {
    val isPro: Boolean

    /**
     * Единая точка входа для paywall.
     * Editor дергает это на любой locked click.
     */
    fun onLockedClick()

    /**
     * Возвращает состояние для DeviceParamsEditor.
     * seed — стартовое состояние (из DefaultDevice, Device, или VM ui).
     */
    @Composable
    fun state(key: K, seed: DeviceParamsDraft): DeviceParamsEditorState<K>
}

data class DeviceParamsEditorState<K>(
    val key: K,
    val draft: DeviceParamsDraft,
    val errors: DeviceParamsErrors,

    val onNameChange: (String) -> Unit,
    val onPowerTextChange: (String) -> Unit,

    val onDeviceTypeChange: (ru.mugalimov.volthome.domain.model.DeviceType) -> Unit,
    val onPowerFactorTextChange: (String) -> Unit,
    val onDemandRatioTextChange: (String) -> Unit,
    val onVoltageTypeChange: (ru.mugalimov.volthome.domain.model.VoltageType) -> Unit,

    val onHasMotorChange: (Boolean) -> Unit,
    val onRequiresDedicatedCircuitChange: (Boolean) -> Unit,
    val onRequiresSocketConnectionChange: (Boolean) -> Unit,
)