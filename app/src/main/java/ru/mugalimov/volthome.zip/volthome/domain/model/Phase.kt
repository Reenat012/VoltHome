package ru.mugalimov.volthome.domain.model

enum class Phase {
    A, B, C
}