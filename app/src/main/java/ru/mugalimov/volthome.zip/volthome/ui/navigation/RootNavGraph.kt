package ru.mugalimov.volthome.ui.navigation

import AboutScreen
import MainApp
import WelcomeScreen
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.rememberCoroutineScope
import androidx.navigation.NavGraphBuilder
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.yandex.authsdk.YandexAuthSdk
import androidx.hilt.navigation.compose.hiltViewModel
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import ru.mugalimov.volthome.ui.screens.auth.AuthScreen
import ru.mugalimov.volthome.ui.viewmodel.AuthViewModel

/**
 * Корневой NavHost. Теперь обёрнут в левый Start Drawer.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RootNavGraph(
    sdk: YandexAuthSdk,
    onLogout: () -> Unit = {},
) {
    val rootNavController = rememberNavController()
    val authVm: AuthViewModel = hiltViewModel()

    LaunchedEffect(Unit) { authVm.bootstrap() }

    LaunchedEffect(Unit) {
        authVm.state.collectLatest { state ->
            when (state) {
                is AuthViewModel.State.Success -> {
                    rootNavController.navigate(Screens.MainApp.route) {
                        popUpTo(Screens.WelcomeScreen.route) { inclusive = true }
                        launchSingleTop = true
                    }
                }
                is AuthViewModel.State.Idle,
                is AuthViewModel.State.Error -> {
                    rootNavController.navigate(Screens.WelcomeScreen.route) {
                        popUpTo(0) { inclusive = true }
                        launchSingleTop = true
                    }
                }
                is AuthViewModel.State.Loading -> Unit
            }
        }
    }

    // --- Drawer state + обёртка всего приложения ---
    val drawerState = rememberDrawerState(DrawerValue.Closed)
    val scope = rememberCoroutineScope()

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            DrawerContent(
                onNavigateRooms = {
                    scope.launch { drawerState.close() }
                    rootNavController.navigate(Screens.RoomsList.route) {
                        launchSingleTop = true
                    }
                },
                onNavigateProfile = {
                    scope.launch { drawerState.close() }
                    rootNavController.navigate(Screens.ProfileScreen.route) {
                        launchSingleTop = true
                    }
                },
                onNavigateSettings = {
                    scope.launch { drawerState.close() }
                    rootNavController.navigate(Screens.SettingsScreen.route) {
                        launchSingleTop = true
                    }
                },
                onNavigateSubscription = {
                    // Если нет экрана — можно показывать Snackbar("Скоро")
                    scope.launch { drawerState.close() }
                },
                onNavigateAbout = {
                    scope.launch { drawerState.close() }
                    rootNavController.navigate(Screens.AboutScreen.route) {
                        launchSingleTop = true
                    }
                },
                onCreateProject = {
                    // Вызови диалог создания проекта и открой его
                    scope.launch { drawerState.close() }
                },
                onLogout = {
                    scope.launch { drawerState.close() }
                    onLogout()
                }
            )
        }
    ) {
        // Делаем Drawer доступным для AppBar через CompositionLocal
        CompositionLocalProvider(LocalDrawerState provides drawerState) {
            NavHost(
                navController = rootNavController,
                startDestination = Screens.WelcomeScreen.route
            ) {
                authGraph(sdk, authVm)
                mainGraph(rootNavController, authVm)
                aboutGraph(rootNavController)
            }
        }
    }
}

private fun NavGraphBuilder.authGraph(
    sdk: YandexAuthSdk,
    authVm: AuthViewModel
) {
    composable(Screens.WelcomeScreen.route) {
        AuthScreen(sdk = sdk) { authVm.bootstrap() }
    }
}

private fun NavGraphBuilder.mainGraph(
    rootNavController: NavHostController,
    authVm: AuthViewModel
) {
    composable(Screens.MainApp.route) {
        MainApp(
            rootNavController = rootNavController,
            authVm = authVm
        )
    }
}

private fun NavGraphBuilder.aboutGraph(
    rootNavController: NavHostController
) {
    composable(Screens.AboutScreen.route) {
        AboutScreen(onBack = { rootNavController.popBackStack() })
    }
}