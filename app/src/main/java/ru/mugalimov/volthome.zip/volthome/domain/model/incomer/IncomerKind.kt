package ru.mugalimov.volthome.domain.model.incomer

enum class IncomerKind { MCB_PLUS_RCD, RCBO, MCB_ONLY }