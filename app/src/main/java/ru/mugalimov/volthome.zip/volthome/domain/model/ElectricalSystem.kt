package ru.mugalimov.volthome.domain.model

// Общая электрическая система
data class ElectricalSystem(val groups: List<CircuitGroup>)
