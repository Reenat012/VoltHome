package ru.mugalimov.volthome.ui.screens.rooms

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.relocation.BringIntoViewRequester
import androidx.compose.foundation.relocation.bringIntoViewRequester
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import ru.mugalimov.volthome.core.validation.InputConstraints
import ru.mugalimov.volthome.domain.model.*
import ru.mugalimov.volthome.domain.model.create.DeviceCreateRequest
import ru.mugalimov.volthome.ui.components.device.adapter.DeviceParamsDraft
import ru.mugalimov.volthome.ui.components.device.adapter.DeviceParamsValidator
import ru.mugalimov.volthome.ui.model.LocalUserPlan
import ru.mugalimov.volthome.ui.paywall.PaywallBus
import javax.inject.Inject

/**
 * Экран добавления комнаты с устройствами.
 * Реализован на BottomSheetScaffold.
 * Контент внутри реагирует на клавиатуру через imePadding().
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddRoomSheet(
    defaultDevices: List<DefaultDevice>,
    roomTypes: List<RoomType>,
    onConfirm: (name: String, roomType: RoomType, devices: List<DeviceCreateRequest>) -> Unit,
    onDismiss: () -> Unit,
    paywallBus: PaywallBus = hiltViewModel<AddRoomSheetPaywallHolder>().paywallBus
) {
    var name by remember { mutableStateOf("") }
    var selectedType by remember { mutableStateOf(roomTypes.firstOrNull() ?: RoomType.STANDARD) }

    val qtyMap = remember { mutableStateMapOf<String, Int>() }
    val expandedMap = remember { mutableStateMapOf<String, Boolean>() }
    val nameOverride = remember { mutableStateMapOf<String, String>() }
    val powerOverride = remember { mutableStateMapOf<String, String>() }
    val powerErrors = remember { mutableStateMapOf<String, String?>() }

    // ✅ Advanced overrides (применяются только для PRO)
    val pfOverride = remember { mutableStateMapOf<String, String>() }
    val drOverride = remember { mutableStateMapOf<String, String>() }

    // ✅ voltage — через dropdown (AC_1PHASE/AC_3PHASE), DC disabled
    val voltageOverride = remember { mutableStateMapOf<String, Voltage>() }

    // ✅ новые: deviceType + флаги (PRO)
    val deviceTypeOverride = remember { mutableStateMapOf<String, DeviceType>() }
    val hasMotorOverride = remember { mutableStateMapOf<String, Boolean>() }
    val requiresDedicatedOverride = remember { mutableStateMapOf<String, Boolean>() }
    val requiresSocketOverride = remember { mutableStateMapOf<String, Boolean>() }

    val bringIntoViewRequester = remember { BringIntoViewRequester() }
    val scope = rememberCoroutineScope()

    val isPro = LocalUserPlan.current.isPro

    val scaffoldState = rememberBottomSheetScaffoldState(
        bottomSheetState = rememberStandardBottomSheetState(
            initialValue = SheetValue.Expanded,
            skipHiddenState = false
        )
    )

    LaunchedEffect(Unit) { applyPresetFor(selectedType, defaultDevices, qtyMap) }

    // агрегированное состояние валидности:
    val hasAnyQty by remember { derivedStateOf { qtyMap.values.any { it > 0 } } }
    val hasErrors by remember {
        derivedStateOf { qtyMap.any { (k, v) -> v > 0 && powerErrors[k] != null } }
    }

    // ✅ при свайпе вниз состояние уходит в Hidden/PartiallyExpanded — закрываем
    LaunchedEffect(scaffoldState.bottomSheetState) {
        snapshotFlow { scaffoldState.bottomSheetState.currentValue }
            .collectLatest { value ->
                if (value == SheetValue.Hidden || value == SheetValue.PartiallyExpanded) {
                    onDismiss()
                }
            }
    }

    BottomSheetScaffold(
        scaffoldState = scaffoldState,
        sheetPeekHeight = 0.dp,
        sheetShape = RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp),
        sheetContent = {
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .imePadding()
                    .bringIntoViewRequester(bringIntoViewRequester),
                contentPadding = PaddingValues(
                    start = 16.dp,
                    end = 16.dp,
                    top = 12.dp,
                    bottom = 88.dp
                ),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            "Добавить комнату",
                            style = MaterialTheme.typography.titleLarge,
                            modifier = Modifier.weight(1f)
                        )
                        IconButton(
                            enabled = hasAnyQty && !hasErrors,
                            onClick = {
                                val requests = buildRequests(
                                    defaults = defaultDevices,
                                    qtyMap = qtyMap,
                                    nameOverride = nameOverride,
                                    powerOverride = powerOverride,
                                    isPro = isPro,
                                    pfOverride = pfOverride,
                                    drOverride = drOverride,
                                    voltageOverride = voltageOverride,
                                    deviceTypeOverride = deviceTypeOverride,
                                    hasMotorOverride = hasMotorOverride,
                                    requiresDedicatedOverride = requiresDedicatedOverride,
                                    requiresSocketOverride = requiresSocketOverride
                                )
                                onConfirm(
                                    name.ifBlank { roomTypeLabel(selectedType) },
                                    selectedType,
                                    requests
                                )
                                onDismiss()
                            }
                        ) {
                            Icon(Icons.Rounded.Check, contentDescription = "Создать")
                        }
                    }
                }

                item {
                    OutlinedTextField(
                        value = name,
                        onValueChange = { name = it },
                        label = { Text("Название комнаты") },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .onFocusChanged {
                                if (it.isFocused) scope.launch {
                                    delay(200); bringIntoViewRequester.bringIntoView()
                                }
                            }
                    )
                }

                item {
                    RoomTypeRow(
                        types = roomTypes,
                        selected = selectedType,
                        onSelect = {
                            selectedType = it
                            applyPresetFor(it, defaultDevices, qtyMap)
                        }
                    )
                }

                item {
                    Text("Устройства", style = MaterialTheme.typography.titleMedium)
                }

                items(defaultDevices, key = { it.id }) { device ->
                    val key = device.id.toString()
                    val expanded = expandedMap[key] == true
                    val qty = qtyMap[key] ?: 0
                    val err = powerErrors[key]

                    // показываем overrides (если есть), иначе дефолт
                    val pfText = pfOverride[key] ?: device.powerFactor.format(2)
                    val drText = drOverride[key] ?: device.demandRatio.format(2)

                    val type = deviceTypeOverride[key] ?: device.deviceType
                    val volt = voltageOverride[key] ?: device.voltage

                    val hasMotor = hasMotorOverride[key] ?: device.hasMotor
                    val reqDedicated =
                        requiresDedicatedOverride[key] ?: device.requiresDedicatedCircuit
                    val reqSocket = requiresSocketOverride[key] ?: device.requiresSocketConnection

                    DeviceRowEditable(
                        device = device,
                        expanded = expanded,
                        qty = qty,
                        title = nameOverride[key] ?: device.name,
                        powerText = powerOverride[key] ?: device.power.toString(),
                        onToggle = { expandedMap[key] = !(expandedMap[key] ?: false) },
                        onInc = { qtyMap[key] = (qtyMap[key] ?: 0).plus(1).coerceAtMost(99) },
                        onDec = { qtyMap[key] = (qtyMap[key] ?: 0).minus(1).coerceAtLeast(0) },
                        onTitleChange = { nameOverride[key] = it },
                        onPowerChange = { newText ->
                            val cleaned = DeviceParamsValidator.normalizePowerText(newText)
                            powerOverride[key] = cleaned
                            val errs = DeviceParamsValidator.validate(
                                DeviceParamsDraft(
                                    name = nameOverride[key] ?: device.name,
                                    powerText = cleaned,
                                    deviceType = deviceTypeOverride[key] ?: device.deviceType,
                                    powerFactorText = pfOverride[key]
                                        ?: device.powerFactor.format(2),
                                    demandRatioText = drOverride[key]
                                        ?: device.demandRatio.format(2),
                                    voltageType = (voltageOverride[key] ?: device.voltage).type,
                                    hasMotor = hasMotorOverride[key] ?: device.hasMotor,
                                    requiresDedicatedCircuit = requiresDedicatedOverride[key]
                                        ?: device.requiresDedicatedCircuit,
                                    requiresSocketConnection = requiresSocketOverride[key]
                                        ?: device.requiresSocketConnection
                                )
                            )
                            powerErrors[key] = errs.powerError
                        },
                        powerError = err,
                        bringIntoViewRequester = bringIntoViewRequester,
                        scope = scope,

                        // ✅ Advanced (PRO gating)
                        isPro = isPro,
                        paywallBus = paywallBus,

                        deviceType = type,
                        onDeviceTypeChange = { deviceTypeOverride[key] = it },

                        powerFactorText = pfText,
                        onPowerFactorChange = { pfOverride[key] = it },

                        demandRatioText = drText,
                        onDemandRatioChange = { drOverride[key] = it },

                        voltage = volt,
                        onVoltageTypeChange = { vt ->
                            voltageOverride[key] = when (vt) {
                                VoltageType.AC_1PHASE -> Voltage(220, VoltageType.AC_1PHASE)
                                VoltageType.AC_3PHASE -> Voltage(380, VoltageType.AC_3PHASE)
                                VoltageType.DC -> volt // DC недоступен; на всякий
                            }
                        },

                        hasMotor = hasMotor,
                        onHasMotorChange = { hasMotorOverride[key] = it },

                        requiresDedicatedCircuit = reqDedicated,
                        onRequiresDedicatedCircuitChange = { requiresDedicatedOverride[key] = it },

                        requiresSocketConnection = reqSocket,
                        onRequiresSocketConnectionChange = { requiresSocketOverride[key] = it }
                    )
                }
            }
        },
        content = { /* основной экран здесь пустой */ }
    )
}

@Composable
private fun RoomTypeRow(
    types: List<RoomType>,
    selected: RoomType,
    onSelect: (RoomType) -> Unit
) {
    FlowRow(
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        types.forEach { t ->
            val isSel = t == selected
            Surface(
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(
                    1.dp,
                    if (isSel) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant
                ),
                color = if (isSel) MaterialTheme.colorScheme.primary.copy(alpha = 0.12f)
                else MaterialTheme.colorScheme.surface
            ) {
                Text(
                    roomTypeLabel(t),
                    modifier = Modifier
                        .clickable { onSelect(t) }
                        .padding(horizontal = 10.dp, vertical = 6.dp),
                    color = if (isSel) MaterialTheme.colorScheme.primary
                    else MaterialTheme.colorScheme.onSurfaceVariant,
                    style = MaterialTheme.typography.labelLarge
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun DeviceRowEditable(
    device: DefaultDevice,
    expanded: Boolean,
    qty: Int,
    title: String,
    powerText: String,
    powerError: String?,
    onToggle: () -> Unit,
    onInc: () -> Unit,
    onDec: () -> Unit,
    onTitleChange: (String) -> Unit,
    onPowerChange: (String) -> Unit,
    bringIntoViewRequester: BringIntoViewRequester,
    scope: CoroutineScope,

    // ✅ Advanced gating
    isPro: Boolean,
    paywallBus: PaywallBus,

    // ✅ new fields
    deviceType: DeviceType,
    onDeviceTypeChange: (DeviceType) -> Unit,

    powerFactorText: String,
    onPowerFactorChange: (String) -> Unit,

    demandRatioText: String,
    onDemandRatioChange: (String) -> Unit,

    voltage: Voltage,
    onVoltageTypeChange: (VoltageType) -> Unit,

    hasMotor: Boolean,
    onHasMotorChange: (Boolean) -> Unit,

    requiresDedicatedCircuit: Boolean,
    onRequiresDedicatedCircuitChange: (Boolean) -> Unit,

    requiresSocketConnection: Boolean,
    onRequiresSocketConnectionChange: (Boolean) -> Unit,
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(Modifier.padding(horizontal = 12.dp, vertical = 10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .clickable { onToggle() }
                ) {
                    Text(device.name, style = MaterialTheme.typography.titleMedium)
                    if (!expanded) {
                        Text(
                            "${device.power} Вт",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    IconButton(onClick = onDec) {
                        Icon(Icons.Rounded.Remove, contentDescription = "Уменьшить")
                    }
                    Box(Modifier.width(28.dp), contentAlignment = Alignment.Center) {
                        Text(qty.toString())
                    }
                    IconButton(onClick = onInc) {
                        Icon(Icons.Rounded.Add, contentDescription = "Увеличить")
                    }
                }
                IconButton(onClick = { onToggle() }) {
                    Icon(
                        if (expanded) Icons.Rounded.ExpandLess else Icons.Rounded.ExpandMore,
                        contentDescription = null
                    )
                }
            }

            AnimatedVisibility(visible = expanded) {
                Column(modifier = Modifier.padding(top = 8.dp)) {

                    // 1) Название — FREE
                    OutlinedTextField(
                        value = title,
                        onValueChange = onTitleChange,
                        label = { Text("Название") },
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(min = 56.dp)
                            .onFocusChanged {
                                if (it.isFocused) scope.launch {
                                    delay(200); bringIntoViewRequester.bringIntoView()
                                }
                            }
                    )

                    Spacer(Modifier.height(10.dp))

                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        // Ряд 1: Мощность (FREE) | Тип устройства (PRO dropdown)
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(12.dp),
                            verticalAlignment = Alignment.Top
                        ) {
                            OutlinedTextField(
                                value = powerText,
                                onValueChange = onPowerChange,
                                label = { Text("Мощность (Вт)") },
                                singleLine = true,
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                                trailingIcon = {
                                    Icon(
                                        Icons.Rounded.ElectricBolt,
                                        contentDescription = null
                                    )
                                },
                                isError = powerError != null,
                                supportingText = {
                                    Text(
                                        powerError ?: "Мощность должна быть в допустимых пределах"
                                    )
                                },
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .heightIn(min = 56.dp)
                                    .onFocusChanged {
                                        if (it.isFocused) scope.launch {
                                            delay(200); bringIntoViewRequester.bringIntoView()
                                        }
                                    }
                            )

                            EnumDropdownField(
                                label = "Тип устройства",
                                value = deviceType,
                                values = DeviceType.values().toList(),
                                valueLabel = { it.name },
                                locked = !isPro,
                                onLockedClick = { paywallBus.request(ProFeature.ADVANCED_DEVICE_EDITOR) },
                                onValueChange = onDeviceTypeChange,
                                modifier = Modifier.weight(1f)
                            )
                        }

                        // Ряд 2: PF | Кс (PRO) — редактируемые поля, в FREE клики → paywall
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(12.dp),
                            verticalAlignment = Alignment.Top
                        ) {
                            LockedDecimalField(
                                label = "Коэфф. мощности (PF)",
                                value = powerFactorText,
                                locked = !isPro,
                                hint = "Влияет на расчёт тока",
                                error = validateRatio(powerFactorText),
                                onLockedClick = { paywallBus.request(ProFeature.ADVANCED_DEVICE_EDITOR) },
                                onValueChange = {
                                    onPowerFactorChange(
                                        it.trim().replace(',', '.')
                                    )
                                },
                                modifier = Modifier.weight(1f),
                                bringIntoViewRequester = bringIntoViewRequester,
                                scope = scope
                            )

                            LockedDecimalField(
                                label = "Коэфф. спроса",
                                value = demandRatioText,
                                locked = !isPro,
                                hint = "Учитывает реальную нагрузку",
                                error = validateRatio(demandRatioText),
                                onLockedClick = { paywallBus.request(ProFeature.ADVANCED_DEVICE_EDITOR) },
                                onValueChange = {
                                    onDemandRatioChange(
                                        it.trim().replace(',', '.')
                                    )
                                },
                                modifier = Modifier.weight(1f),
                                bringIntoViewRequester = bringIntoViewRequester,
                                scope = scope
                            )
                        }

                        // Ряд 3: Напряжение (PRO dropdown), DC disabled
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(12.dp),
                            verticalAlignment = Alignment.Top
                        ) {
                            VoltageTypeDropdownField(
                                label = "Напряжение",
                                value = voltage.type,
                                locked = !isPro,
                                onLockedClick = { paywallBus.request(ProFeature.ADVANCED_DEVICE_EDITOR) },
                                onValueChange = onVoltageTypeChange,
                                modifier = Modifier.weight(1f)
                            )
                            Spacer(Modifier.weight(1f))
                        }

                        // Ряд 4: Флаги (PRO)
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(12.dp),
                            verticalAlignment = Alignment.Top
                        ) {
                            YesNoDropdownField(
                                label = "Есть двигатель",
                                value = hasMotor,
                                locked = !isPro,
                                onLockedClick = { paywallBus.request(ProFeature.ADVANCED_DEVICE_EDITOR) },
                                onValueChange = onHasMotorChange,
                                modifier = Modifier.weight(1f)
                            )
                            YesNoDropdownField(
                                label = "Выделенная линия",
                                value = requiresDedicatedCircuit,
                                locked = !isPro,
                                onLockedClick = { paywallBus.request(ProFeature.ADVANCED_DEVICE_EDITOR) },
                                onValueChange = onRequiresDedicatedCircuitChange,
                                modifier = Modifier.weight(1f)
                            )
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(12.dp),
                            verticalAlignment = Alignment.Top
                        ) {
                            YesNoDropdownField(
                                label = "Подключение розеткой",
                                value = requiresSocketConnection,
                                locked = !isPro,
                                onLockedClick = { paywallBus.request(ProFeature.ADVANCED_DEVICE_EDITOR) },
                                onValueChange = onRequiresSocketConnectionChange,
                                modifier = Modifier.weight(1f)
                            )
                            Spacer(Modifier.weight(1f))
                        }
                    }
                }
            }
        }
    }
}

/* ====== Хелперы ====== */

private fun buildRequests(
    defaults: List<DefaultDevice>,
    qtyMap: Map<String, Int>,
    nameOverride: Map<String, String>,
    powerOverride: Map<String, String>,
    isPro: Boolean,
    pfOverride: Map<String, String>,
    drOverride: Map<String, String>,
    voltageOverride: Map<String, Voltage>,
    deviceTypeOverride: Map<String, DeviceType>,
    hasMotorOverride: Map<String, Boolean>,
    requiresDedicatedOverride: Map<String, Boolean>,
    requiresSocketOverride: Map<String, Boolean>
): List<DeviceCreateRequest> {
    val byId = defaults.associateBy { it.id.toString() }
    val out = mutableListOf<DeviceCreateRequest>()

    for ((key, count) in qtyMap) {
        if (count <= 0) continue
        val def = byId[key] ?: continue

        val title = (nameOverride[key] ?: def.name).trim().ifEmpty { def.name }

        val cleaned =
            DeviceParamsValidator.normalizePowerText(powerOverride[key] ?: def.power.toString())
        val powerRaw = cleaned.toDoubleOrNull()?.takeIf { it > 0.0 } ?: def.power.toDouble()
        val watts = powerRaw.toInt().coerceAtLeast(1)

        // ✅ advanced применяем только если PRO (в FREE — игнорим overrides)
        val pf = if (isPro) pfOverride[key]?.trim()?.replace(',', '.')?.toDoubleOrNull() else null
        val dr = if (isPro) drOverride[key]?.trim()?.replace(',', '.')?.toDoubleOrNull() else null

        val type = if (isPro) (deviceTypeOverride[key] ?: def.deviceType) else def.deviceType
        val volt = if (isPro) (voltageOverride[key] ?: def.voltage) else def.voltage

        val hm = if (isPro) hasMotorOverride[key] else null
        val rd = if (isPro) requiresDedicatedOverride[key] else null
        val rs = if (isPro) requiresSocketOverride[key] else null

        out += DeviceCreateRequest(
            title = title,
            type = type,
            count = count,
            ratedPowerW = watts,
            powerFactor = pf ?: def.powerFactor,
            demandRatio = dr ?: def.demandRatio,
            voltage = volt,
            hasMotor = hm ?: def.hasMotor,
            requiresDedicatedCircuit = rd ?: def.requiresDedicatedCircuit,
            requiresSocketConnection = rs ?: def.requiresSocketConnection
        )
    }
    return out
}

private fun roomTypeLabel(type: RoomType): String = when (type) {
    RoomType.STANDARD -> "Стандартная"
    RoomType.BATHROOM -> "Ванная (УЗО)"
    RoomType.KITCHEN -> "Кухня (УЗО)"
    RoomType.OUTDOOR -> "Улица (УЗО)"
}

private fun Double.format(digits: Int) = "%.${digits}f".format(this).replace(',', '.')

private fun applyPresetFor(
    type: RoomType,
    all: List<DefaultDevice>,
    qtyMap: MutableMap<String, Int>
) {
    qtyMap.clear()
    fun addFirstOf(dt: DeviceType, count: Int = 1) {
        val item = all.firstOrNull { it.deviceType == dt } ?: return
        qtyMap[item.id.toString()] = count
    }
    when (type) {
        RoomType.STANDARD -> {
            addFirstOf(DeviceType.LIGHTING, 1)
            addFirstOf(DeviceType.SOCKET, 1)
        }

        RoomType.BATHROOM -> {
            addFirstOf(DeviceType.LIGHTING, 1)
            addFirstOf(DeviceType.SOCKET, 1)
            addFirstOf(DeviceType.HEAVY_DUTY, 1)
        }

        RoomType.KITCHEN -> {
            addFirstOf(DeviceType.LIGHTING, 1)
            addFirstOf(DeviceType.SOCKET, 2)
            addFirstOf(DeviceType.HEAVY_DUTY, 1)
        }

        RoomType.OUTDOOR -> addFirstOf(DeviceType.SOCKET, 1)
    }
}

/* ====== UI blocks: dropdown + locked fields ====== */

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun <T> EnumDropdownField(
    label: String,
    value: T,
    values: List<T>,
    valueLabel: (T) -> String,
    locked: Boolean,
    onLockedClick: () -> Unit,
    onValueChange: (T) -> Unit,
    modifier: Modifier = Modifier
) {
    var expanded by remember { mutableStateOf(false) }

    val open = {
        if (locked) onLockedClick() else expanded = true
    }

    ExposedDropdownMenuBox(
        expanded = expanded,
        onExpandedChange = { open() },
        modifier = modifier
            .fillMaxWidth()
            .heightIn(min = 56.dp)
    ) {
        OutlinedTextField(
            value = valueLabel(value),
            onValueChange = {},
            readOnly = true,
            enabled = true,
            singleLine = true,
            label = { Text(label) },
            trailingIcon = {
                if (locked) Icon(Icons.Rounded.Lock, contentDescription = null)
                else ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded)
            },
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier
                .menuAnchor()
                .fillMaxWidth()
        )

        ExposedDropdownMenu(
            expanded = expanded,
            onDismissRequest = { expanded = false }
        ) {
            values.forEach { item ->
                DropdownMenuItem(
                    text = { Text(valueLabel(item)) },
                    onClick = {
                        expanded = false
                        onValueChange(item)
                    }
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun VoltageTypeDropdownField(
    label: String,
    value: VoltageType,
    locked: Boolean,
    onLockedClick: () -> Unit,
    onValueChange: (VoltageType) -> Unit,
    modifier: Modifier = Modifier
) {
    var expanded by remember { mutableStateOf(false) }

    val open = {
        if (locked) onLockedClick() else expanded = true
    }

    ExposedDropdownMenuBox(
        expanded = expanded,
        onExpandedChange = { open() },
        modifier = modifier
            .fillMaxWidth()
            .heightIn(min = 56.dp)
    ) {
        OutlinedTextField(
            value = when (value) {
                VoltageType.AC_1PHASE -> "AC 1ф (220 В)"
                VoltageType.AC_3PHASE -> "AC 3ф (380 В)"
                VoltageType.DC -> "DC"
            },
            onValueChange = {},
            readOnly = true,
            enabled = true,
            singleLine = true,
            label = { Text(label) },
            supportingText = { Text("DC пока недоступен") },
            trailingIcon = {
                if (locked) Icon(Icons.Rounded.Lock, contentDescription = null)
                else ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded)
            },
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier
                .menuAnchor()
                .fillMaxWidth()
        )

        ExposedDropdownMenu(
            expanded = expanded,
            onDismissRequest = { expanded = false }
        ) {
            DropdownMenuItem(
                text = { Text("AC 1ф (220 В)") },
                onClick = { expanded = false; onValueChange(VoltageType.AC_1PHASE) }
            )
            DropdownMenuItem(
                text = { Text("AC 3ф (380 В)") },
                onClick = { expanded = false; onValueChange(VoltageType.AC_3PHASE) }
            )
            DropdownMenuItem(
                enabled = false,
                text = { Text("DC — скоро") },
                onClick = {}
            )
        }
    }
}

@Composable
private fun YesNoDropdownField(
    label: String,
    value: Boolean,
    locked: Boolean,
    onLockedClick: () -> Unit,
    onValueChange: (Boolean) -> Unit,
    modifier: Modifier = Modifier
) {
    EnumDropdownField(
        label = label,
        value = value,
        values = listOf(true, false),
        valueLabel = { if (it) "Да" else "Нет" },
        locked = locked,
        onLockedClick = onLockedClick,
        onValueChange = onValueChange,
        modifier = modifier
    )
}

@Composable
private fun LockedDecimalField(
    label: String,
    value: String,
    locked: Boolean,
    hint: String?,
    error: String?,
    onLockedClick: () -> Unit,
    onValueChange: (String) -> Unit,
    modifier: Modifier,
    bringIntoViewRequester: BringIntoViewRequester,
    scope: CoroutineScope
) {
    val m = modifier
        .fillMaxWidth()
        .heightIn(min = 56.dp)
        .let { base -> if (locked) base.clickable { onLockedClick() } else base }

    OutlinedTextField(
        value = value,
        onValueChange = { if (!locked) onValueChange(it) },
        label = { Text(label) },
        enabled = true,
        readOnly = locked,
        singleLine = true,
        isError = (error != null && !locked),
        supportingText = {
            when {
                locked && hint != null -> Text(hint)
                !locked && error != null -> Text(error)
                hint != null -> Text(hint)
            }
        },
        trailingIcon = { if (locked) Icon(Icons.Rounded.Lock, contentDescription = null) },
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
        shape = RoundedCornerShape(12.dp),
        modifier = m.onFocusChanged {
            if (it.isFocused) scope.launch {
                delay(200)
                bringIntoViewRequester.bringIntoView()
            }
        }
    )
}

private fun validateRatio(input: String): String? {
    val v = input.trim().replace(',', '.').toDoubleOrNull()
    if (v == null) return "Введите число"
    if (v < 0.1 || v > 1.0) return "Допустимо 0.1 — 1.0"
    return null
}

/**
 * Хелпер, чтобы получить PaywallBus через Hilt без ручного DI в composable.
 */
@HiltViewModel
class AddRoomSheetPaywallHolder @Inject constructor(
    val paywallBus: PaywallBus
) : androidx.lifecycle.ViewModel()