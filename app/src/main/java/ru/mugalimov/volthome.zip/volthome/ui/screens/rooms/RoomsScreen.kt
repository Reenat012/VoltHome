package ru.mugalimov.volthome.ui.screens.rooms

import android.annotation.SuppressLint
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.SnackbarResult
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.hilt.navigation.compose.hiltViewModel
import kotlinx.coroutines.launch
import ru.mugalimov.volthome.domain.model.RoomType
import ru.mugalimov.volthome.ui.components.ErrorView
import ru.mugalimov.volthome.ui.components.LoadingView
import ru.mugalimov.volthome.ui.sheets.AddRoomSheet
import ru.mugalimov.volthome.ui.viewmodel.RoomViewModel
import ru.mugalimov.volthome.ui.viewmodel.RoomsAction
import ru.mugalimov.volthome.ui.viewmodel.RoomsViewModel

/**
 * Экран отображения списка комнат (переведён на новый поток «Комната + устройства»).
 * Старые параметры сохранены для совместимости; onAddRoom теперь не используется.
 */
@OptIn(ExperimentalMaterial3Api::class)
@SuppressLint("NotConstructor")
@Composable
fun RoomsScreen(
    onClickRoom: (Long) -> Unit,          // обработчик клика на комнату (навигация в детали)
    onAddRoom: () -> Unit,                // (legacy) — больше не используется, оставлен для совместимости
    viewModel: RoomViewModel = hiltViewModel(),      // VM списка (как раньше)
    addViewModel: RoomsViewModel = hiltViewModel()   // новая VM для создания комнат
) {
    // ---- Состояние списка из старой VM ----
    val uiState by viewModel.uiState.collectAsState()

    // ---- Состояние создания из новой VM ----
    val defaultDevices by addViewModel.defaultDevices.collectAsState()
    val isBusy by addViewModel.isBusy.collectAsState()

    val snackbarHostState = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()

    var showAddRoom by remember { mutableStateOf(false) }

    // ---- Обработка одноразовых событий от новой VM ----
    LaunchedEffect(Unit) {
        addViewModel.actions.collect { action: RoomsAction ->
            when (action) {
                is RoomsAction.RoomCreated -> {
                    // Навигация сразу в созданную комнату
                    onClickRoom(action.roomId)

                    // Snackbar с Undo удаления комнаты (каскадом удалятся устройства)
                    val res = snackbarHostState.showSnackbar(
                        message = "Комната создана (+${action.deviceIds.size})",
                        actionLabel = "Отменить",
                        withDismissAction = true
                    )
                    if (res == SnackbarResult.ActionPerformed) {
                        addViewModel.undoCreateRoom(action.roomId)
                    }
                }
                // Если у тебя в RoomsAction ещё есть DevicesAdded — игнорируем на этом экране
                is RoomsAction.DevicesAdded -> Unit
                is RoomsAction.UserMessage -> snackbarHostState.showSnackbar(action.message)
                is RoomsAction.Error -> snackbarHostState.showSnackbar(
                    "Ошибка: ${action.throwable.localizedMessage ?: "неизвестная"}"
                )
            }
        }
    }

    // FAB в M3 без enabled — ставим guard и визуальный alpha
    val fabDisabled = isBusy
    val fabAlpha = if (fabDisabled) 0.5f else 1f

    Scaffold(
        topBar = { TopAppBar(title = { Text("Комнаты") }) },
        snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
        floatingActionButton = {
            FloatingActionButton(
                onClick = { if (!fabDisabled) showAddRoom = true },
                modifier = Modifier.alpha(fabAlpha)
            ) {
                Icon(Icons.Default.Add, contentDescription = "Добавить")
            }
        }
    ) { padding ->
        when {
            uiState.isLoading -> LoadingView()
            uiState.error != null -> ErrorView(uiState.error!!)
            else -> RoomList(
                rooms = uiState.rooms,
                onDelete = viewModel::deleteRoom, // как и раньше
                modifier = Modifier.padding(padding),
                onClickRoom = onClickRoom
            )
        }
    }

    if (showAddRoom) {
        AddRoomSheet(
            defaultDevices = defaultDevices,
            roomTypes = RoomType.values().toList(), // при желании — свой порядок/локализация
            onConfirm = { name, type, selected ->
                addViewModel.createRoomWithDevices(name, type, selected)
                showAddRoom = false
            },
            onDismiss = { showAddRoom = false }
        )
    }
}