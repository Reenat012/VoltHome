package ru.mugalimov.volthome.ui.sheets

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import ru.mugalimov.volthome.domain.model.DefaultDevice
import ru.mugalimov.volthome.domain.model.RoomType
import ru.mugalimov.volthome.ui.components.QtyStepper
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions


@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddRoomSheet(
    defaultDevices: List<DefaultDevice>,
    roomTypes: List<RoomType>,
    onConfirm: (name: String, type: RoomType, selected: List<Pair<DefaultDevice, Int>>) -> Unit,
    onDismiss: () -> Unit
) {
    val focus = LocalFocusManager.current
    var name by remember { mutableStateOf("") }

    // выпадающий список типов
    var expanded by remember { mutableStateOf(false) }
    var type by remember { mutableStateOf(roomTypes.firstOrNull() ?: RoomType.KITCHEN) }

    // qty по устройствам
    val qtyMap = remember { mutableStateMapOf<DefaultDevice, Int>() }

    // Предзаполнение рекомендаций при смене типа
    LaunchedEffect(type, defaultDevices) {
        qtyMap.clear()
        for (d in recommendedFor(type, defaultDevices)) {
            qtyMap[d] = d.defaultQty  // см. extension ниже
        }
    }

    // деривация: можно ли сабмитить?
    val totalQty by remember(qtyMap) { mutableIntStateOf(qtyMap.values.sum()) }
    val confirmEnabled = name.isNotBlank() && (qtyMap.values.sum() > 0)

    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(Modifier.fillMaxWidth().padding(16.dp)) {

            OutlinedTextField(
                value = name,
                onValueChange = { name = it },
                singleLine = true,
                label = { Text("Название комнаты") },
                supportingText = {
                    if (name.isBlank()) Text("Обязательное поле")
                },
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                keyboardActions = KeyboardActions(onDone = { focus.clearFocus() }),
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(Modifier.height(8.dp))

            // Реальный выпадающий список RoomType
            ExposedDropdownMenuBox(
                expanded = expanded,
                onExpandedChange = { expanded = !expanded }
            ) {
                OutlinedTextField(
                    value = type.localizedName(),  // см. extension ниже
                    onValueChange = {},
                    readOnly = true,
                    label = { Text("Тип комнаты") },
                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded) },
                    modifier = Modifier
                        .menuAnchor()
                        .fillMaxWidth()
                )
                ExposedDropdownMenu(
                    expanded = expanded,
                    onDismissRequest = { expanded = false }
                ) {
                    roomTypes.forEach { rt ->
                        DropdownMenuItem(
                            text = { Text(rt.localizedName()) },
                            onClick = {
                                type = rt
                                expanded = false
                            }
                        )
                    }
                }
            }

            Spacer(Modifier.height(12.dp))

            Text("Рекомендуемые устройства", style = MaterialTheme.typography.titleSmall)
            Spacer(Modifier.height(4.dp))

            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 360.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
                userScrollEnabled = true
            ) {
                val items = defaultDevices // можно фильтровать/группировать по категориям
                items(items, key = { it.id ?: it.hashCode() }) { d ->
                    val qty = qtyMap[d] ?: 0
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(d.name, modifier = Modifier.weight(1f))
                        QtyStepper(qty) { new ->
                            if (new <= 0) qtyMap.remove(d) else qtyMap[d] = new
                        }
                    }
                }
            }

            Spacer(Modifier.height(16.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Выбрано: ${qtyMap.values.sum()}",
                    style = MaterialTheme.typography.bodyMedium
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    TextButton(onClick = onDismiss) { Text("Отмена") }
                    Button(
                        enabled = confirmEnabled,
                        onClick = {
                            focus.clearFocus()
                            val selected = qtyMap.map { it.key to it.value }
                            onConfirm(name.trim(), type, selected)
                        }
                    ) { Text("Добавить") }
                }
            }
        }
    }
}

/* ------------ helpers / рекомендации ------------ */

// Простейшая логика «рекомендованных» по RoomType.
// При желании вынести в VM и читать из пресетов.
private fun recommendedFor(type: RoomType, all: List<DefaultDevice>): List<DefaultDevice> {
    // Поиск по точному имени из каталога (без учёта регистра)
    fun pick(vararg names: String): List<DefaultDevice> {
        val want = names.map { it.lowercase() }.toSet()
        val hit = all.filter { it.name.lowercase() in want }
        // если ничего не нашли (вдруг названия поменялись) — вернём базовый минимум
        return if (hit.isNotEmpty()) hit else all.take(4)
    }

    return when (type) {
        RoomType.KITCHEN -> pick(
            "Светодиодная лампа",
            "Люстра",
            "Розетка бытовая",
            "Холодильник",
            "Микроволновая печь",
            "Электрический чайник",
            "Кофеварка",
            "Тостер",
            "Блендер"
        )

        RoomType.BATHROOM -> pick(
            "Светодиодная лампа",
            "Люстра",
            "Розетка бытовая",
            "Стиральная машина",
            "Фен",
            "Обогреватель"
        )

        RoomType.OUTDOOR -> pick(
            "Светодиодная лампа",
            "Розетка бытовая"
        )

        RoomType.STANDARD -> pick(
            "Светодиодная лампа",
            "Люстра",
            "Розетка бытовая",
            "Телевизор",
            "Роутер Wi-Fi",
            "Компьютер",
            "Зарядное устройство"
        )
    }
}

// Кол-во «по умолчанию» для типичных устройств
private val DefaultDevice.defaultQty: Int
    get() = when (name.lowercase()) {
        "светодиодная лампа" -> 2
        "люстра" -> 1
        "розетка бытовая" -> 3
        else -> 1
    }

// Локализованное имя типа (заглушка; подставь свою локализацию)
private fun RoomType.localizedName(): String = when (this) {
    RoomType.KITCHEN  -> "Кухня"
    RoomType.BATHROOM -> "Ванная"
    RoomType.STANDARD -> "Обычное помещение"
    RoomType.OUTDOOR  -> "Улица"
}