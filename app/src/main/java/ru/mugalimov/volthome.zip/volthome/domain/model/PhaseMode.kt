package ru.mugalimov.volthome.domain.model

enum class PhaseMode {
    SINGLE,  // 1 фаза
    THREE    // 3 фазы
}