package ru.mugalimov.volthome.ui.screens.explication

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import ru.mugalimov.volthome.domain.model.Device

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun DeviceChips(
    devices: List<Device>,
    onDeviceClick: (Long) -> Unit,
    onDeviceLongPress: ((Long) -> Unit)? = null,
    enableLongPress: Boolean = false,
    maxVisible: Int = 3,
    groupKey: Any? = null // привязываем state раскрытия к группе
) {
    val rememberKey = groupKey ?: devices.joinToString("|") { it.id.toString() }
    val (expanded, setExpanded) = rememberSaveable(rememberKey) { mutableStateOf(false) }

    val total = devices.size
    val overflow = (total - maxVisible).coerceAtLeast(0)
    val visible = if (expanded || total <= maxVisible) devices else devices.take(maxVisible)

    FlowRow(
        modifier = Modifier.padding(top = 2.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        visible.forEach { d ->
            key(d.id) {
                // ВАЖНО:
                // Мы НЕ используем AssistChip, потому что он сам кликабельный внутри
                // и может "съедать" события, из-за чего наш combinedClickable не срабатывает.
                // Вместо этого — свой chip на Surface с ЕДИНСТВЕННЫМ combinedClickable.
                DeviceChip(
                    text = d.name,
                    onClick = { onDeviceClick(d.id) },
                    onLongClick = if (enableLongPress) {
                        { onDeviceLongPress?.invoke(d.id) }
                    } else {
                        null
                    }
                )
            }
        }

        if (!expanded && overflow > 0) {
            // Кнопка раскрытия — обычный клик, long-press не нужен
            DeviceChip(
                text = "+$overflow",
                onClick = { setExpanded(true) },
                onLongClick = null
            )
        }

        if (expanded && overflow > 0) {
            DeviceChip(
                text = "Свернуть",
                onClick = { setExpanded(false) },
                onLongClick = null
            )
        }
    }
}

@Composable
private fun DeviceChip(
    text: String,
    onClick: () -> Unit,
    onLongClick: (() -> Unit)?
) {
    val cs = MaterialTheme.colorScheme

    Surface(
        shape = MaterialTheme.shapes.large,
        color = cs.surfaceContainerHigh,
        border = BorderStroke(1.dp, cs.outlineVariant.copy(alpha = 0.60f)),
        modifier = Modifier
            .clip(MaterialTheme.shapes.large)
            .combinedClickable(
                // Один источник кликов: tap всегда работает
                onClick = onClick,
                // Long-press активен только когда передан non-null (manual)
                onLongClick = onLongClick
            )
    ) {
        Text(
            text = text,
            style = MaterialTheme.typography.labelLarge,
            color = cs.onSurface,
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
        )
    }
}