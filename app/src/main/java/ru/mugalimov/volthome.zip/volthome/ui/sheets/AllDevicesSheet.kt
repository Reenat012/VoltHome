package ru.mugalimov.volthome.ui.sheets

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import ru.mugalimov.volthome.domain.model.DefaultDevice
import ru.mugalimov.volthome.domain.model.RoomType
import ru.mugalimov.volthome.ui.components.QtyStepper

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AllDevicesSheet(
    defaultDevices: List<DefaultDevice>,
    recent: List<DefaultDevice> = emptyList(), // при желании пробросить из VM
    onConfirm: (List<Pair<DefaultDevice, Int>>) -> Unit,
    onDismiss: () -> Unit
) {
    var query by remember { mutableStateOf("") }
    val selected = remember { mutableStateMapOf<DefaultDevice, Int>() }

    val filtered = remember(query, defaultDevices) {
        if (query.isBlank()) defaultDevices
        else defaultDevices.filter { it.name.contains(query, ignoreCase = true) }
    }

    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(Modifier.fillMaxWidth().padding(16.dp)) {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                label = { Text("Поиск устройств") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(Modifier.height(12.dp))

            LazyColumn(
                modifier = Modifier.fillMaxWidth().heightIn(max = 420.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                if (recent.isNotEmpty() && query.isBlank()) {
                    item { Text("Недавние", style = MaterialTheme.typography.titleSmall) }
                    items(recent, key = { it.id ?: it.hashCode() }) { d ->
                        val qty = selected[d] ?: 0
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(d.name, Modifier.weight(1f))
                            QtyStepper(qty) { new -> if (new <= 0) selected.remove(d) else selected[d] = new }
                        }
                    }
                    item { Spacer(Modifier.height(8.dp)) }
                }

                item { Text("Все устройства", style = MaterialTheme.typography.titleSmall) }

                items(filtered, key = { it.id ?: it.hashCode() }) { d ->
                    val qty = selected[d] ?: 0
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(d.name, Modifier.weight(1f))
                        QtyStepper(qty) { new -> if (new <= 0) selected.remove(d) else selected[d] = new }
                    }
                }
            }

            Spacer(Modifier.height(16.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                TextButton(onClick = onDismiss) { Text("Отмена") }
                Spacer(Modifier.width(8.dp))
                Button(
                    enabled = selected.values.sum() > 0,
                    onClick = { onConfirm(selected.map { it.key to it.value }) }
                ) { Text("Добавить выбранные") }
            }
        }
    }
}