

import ru.mugalimov.volthome.domain.model.CircuitGroup
import ru.mugalimov.volthome.domain.model.Phase
import ru.mugalimov.volthome.domain.model.VoltageType
import kotlin.math.max
import kotlin.math.min

/**
 * Жадное распределение + локальная оптимизация:
 * 1) сортируем по убыванию тока и кладём в наименее загруженную фазу;
 * 2) несколько проходов "переприсваиваем" первые topN тяжёлых групп,
 *    если перенос в другую фазу уменьшает перекос (max - min).
 *
 * Параметры:
 * @param topN       сколько самых тяжёлых групп пытаться улучшать (8–12 обычно достаточно)
 * @param maxPasses  сколько раз проходить по topN (1–3 обычно достаточно)
 */
fun distributeGroupsBalanced(
    groups: List<CircuitGroup>,
    topN: Int = 10,
    maxPasses: Int = 2
): List<CircuitGroup> {
    if (groups.isEmpty()) return emptyList()

    val phases = listOf(Phase.A, Phase.B, Phase.C)
    val sorted = groups.sortedWith(
        compareByDescending<CircuitGroup> { it.nominalCurrent }
            .thenBy { it.groupNumber }    // детерминируем порядок при равных токах
    )

    // --- 1) Жадная раскладка
    val phaseLoads = doubleArrayOf(0.0, 0.0, 0.0)
    val phaseIdxOf = IntArray(sorted.size) { -1 }

    sorted.forEachIndexed { idx, g ->
        val pi = phaseLoads.indices.minBy { phaseLoads[it] }
        phaseLoads[pi] += g.nominalCurrent
        phaseIdxOf[idx] = pi
    }

    // --- 2) Локальная донастройка для первых topN тяжёлых
    val K = min(topN, sorted.size)
    repeat(maxPasses.coerceAtLeast(0)) {
        var improved = false
        for (i in 0 until K) {
            val g = sorted[i]
            val curPi = phaseIdxOf[i]
            val curLoad = phaseLoads.copyOf()

            // Текущий перекос
            var bestPi = curPi
            var bestImb = imbalance(curLoad)

            // Пробуем перенести группу на каждую из 3 фаз
            for (pi in 0..2) {
                if (pi == curPi) continue
                val test = curLoad.copyOf()
                test[curPi] -= g.nominalCurrent
                test[pi]    += g.nominalCurrent
                val imb = imbalance(test)
                if (imb + 1e-9 < bestImb) { // небольшая эпсилон-устойчивость
                    bestImb = imb
                    bestPi = pi
                }
            }

            if (bestPi != curPi) {
                // Применяем лучший перенос
                phaseLoads[curPi] -= g.nominalCurrent
                phaseLoads[bestPi] += g.nominalCurrent
                phaseIdxOf[i] = bestPi
                improved = true
            }
        }
        if (!improved) return@repeat // ранний выход если улучшений нет
    }

    // --- Формируем результат с нормализованной нумерацией групп
    val assigned = sorted.mapIndexed { idx, g ->
        g.copy(
            phase = phases[phaseIdxOf[idx]],
            groupNumber = idx + 1
        )
    }
    return assigned.sortedBy { it.groupNumber }
}

/** Текущий перекос по фазам = max(load) - min(load) */
private fun imbalance(loads: DoubleArray): Double {
    var mn = Double.POSITIVE_INFINITY
    var mx = Double.NEGATIVE_INFINITY
    for (x in loads) {
        if (x < mn) mn = x
        if (x > mx) mx = x
    }
    return mx - mn
}

/** Суммирует токи по уже назначенным фазам (безопасно к null) */
fun phaseCurrents(groups: List<CircuitGroup>): Map<Phase, Double> =
    groups.filter { it.phase != null }
        .groupBy { it.phase!! }
        .mapValues { (_, gs) -> gs.sumOf { it.nominalCurrent } }
        .withDefault { 0.0 }

/** 3Ф, если реально задействовано >= 2 фаз; иначе 1Ф */
fun inferVoltageType(groups: List<CircuitGroup>): VoltageType {
    val used = groups.mapNotNull { it.phase }.toSet()
    return if (used.size >= 2) VoltageType.AC_3PHASE else VoltageType.AC_1PHASE
}
