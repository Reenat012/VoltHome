package ru.mugalimov.volthome.ui.sheets

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.ExpandLess
import androidx.compose.material.icons.rounded.ExpandMore
import androidx.compose.material3.BottomSheetDefaults
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.launch
import ru.mugalimov.volthome.domain.model.DefaultDevice
import ru.mugalimov.volthome.domain.model.DeviceType
import ru.mugalimov.volthome.domain.model.Voltage
import ru.mugalimov.volthome.domain.model.VoltageType
import ru.mugalimov.volthome.domain.use_case.AddDevicesToRoomUseCase

/**
 * Новый шит добавления: сразу можно задать Название + Мощность (Вт/кВт) для каждого выбранного пресета.
 * На "Добавить" формирует DeviceCreateRequest и вызывает AddDevicesToRoomUseCase.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DevicePickerSheet(
    roomId: Long,
    defaultDevices: List<DefaultDevice>,
    onDismiss: () -> Unit,
    onAdded: (List<Long>) -> Unit,
    helperVm: DevicePickerHelperVm = androidx.hilt.navigation.compose.hiltViewModel()
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val scope = rememberCoroutineScope()

    var search by remember { mutableStateOf("") }
    val qty = remember { mutableStateMapOf<Long, Int>() }
    val nameOverride = remember { mutableStateMapOf<Long, String>() }
    val powerOverride = remember { mutableStateMapOf<Long, String>() }
    val unitOverride = remember { mutableStateMapOf<Long, PowerUnit>() }

    val filtered = remember(search, defaultDevices) {
        val q = search.trim().lowercase()
        if (q.isEmpty()) defaultDevices else defaultDevices.filter { it.name.lowercase().contains(q) }
    }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        dragHandle = { BottomSheetDefaults.DragHandle() }
    ) {
        Column(Modifier.padding(horizontal = 16.dp, vertical = 12.dp)) {
            Text("Добавить устройства")

            Spacer(Modifier.height(12.dp))

            OutlinedTextField(
                value = search,
                onValueChange = { search = it },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                placeholder = { Text("Поиск устройства…") }
            )

            Spacer(Modifier.height(8.dp))

            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(10.dp),
                contentPadding = PaddingValues(bottom = 88.dp)
            ) {
                items(filtered, key = { it.id }) { def ->
                    var expanded by remember { mutableStateOf(false) }
                    val count = qty[def.id] ?: 0
                    Card {
                        Column(Modifier.padding(12.dp)) {
                            Row(
                                horizontalArrangement = Arrangement.SpaceBetween,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(Modifier.weight(1f)) {
                                    Text(def.name)
                                    Text("${def.power} Вт • ${def.voltage.toReadableLabel()}")
                                }
                                Row {
                                    Stepper(count = count, onChange = { qty[def.id] = it })
                                    IconButton(onClick = { expanded = !expanded }) {
                                        Icon(
                                            if (expanded) Icons.Rounded.ExpandLess else Icons.Rounded.ExpandMore,
                                            contentDescription = null
                                        )
                                    }
                                }
                            }
                            AnimatedVisibility(expanded) {
                                Column {
                                    Spacer(Modifier.height(8.dp))
                                    OutlinedTextField(
                                        value = nameOverride[def.id] ?: def.name,
                                        onValueChange = { nameOverride[def.id] = it },
                                        label = { Text("Название") },
                                        singleLine = true,
                                        modifier = Modifier.fillMaxWidth()
                                    )
                                    Spacer(Modifier.height(8.dp))
                                    Row {
                                        OutlinedTextField(
                                            value = powerOverride[def.id] ?: def.power.toString(),
                                            onValueChange = { powerOverride[def.id] = it.replace(',', '.') },
                                            label = { Text("Мощность") },
                                            singleLine = true,
                                            keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(
                                                keyboardType = KeyboardType.Decimal
                                            ),
                                            modifier = Modifier.weight(1f)
                                        )
                                        Spacer(Modifier.width(8.dp))
                                        UnitChips(
                                            unit = unitOverride[def.id] ?: PowerUnit.W,
                                            onUnit = { unitOverride[def.id] = it }
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            Spacer(Modifier.height(12.dp))

            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Button(
                    onClick = {
                        scope.launch {
                            val reqs = buildRequests(defaultDevices, qty, nameOverride, powerOverride, unitOverride)
                            if (reqs.isEmpty()) { onDismiss(); return@launch }
                            val ids = helperVm.add(roomId, reqs)
                            onAdded(ids)
                            onDismiss()
                        }
                    }
                ) {
                    Icon(Icons.Rounded.Check, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text("Добавить")
                }
                Button(onClick = onDismiss) { Text("Отмена") }
            }
            Spacer(Modifier.height(8.dp))
        }
    }
}

private enum class PowerUnit { W, kW }

@Composable
private fun Stepper(count: Int, onChange: (Int) -> Unit) {
    Row(
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        modifier = Modifier.clickable { onChange((count + 1).coerceAtMost(99)) }
    ) {
        Text("× $count")
    }
}

@Composable
private fun UnitChips(unit: PowerUnit, onUnit: (PowerUnit) -> Unit) {
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        FilterChip(selected = unit == PowerUnit.W, onClick = { onUnit(PowerUnit.W) }, label = { Text("Вт") })
        FilterChip(selected = unit == PowerUnit.kW, onClick = { onUnit(PowerUnit.kW) }, label = { Text("кВт") })
    }
}

/** Модель для батч-создания инстансов устройства с кастомными полями. */
data class DeviceCreateRequest(
    val title: String,
    val type: DeviceType,
    val count: Int,
    val ratedPowerW: Int,
    val powerFactor: Double,
    val demandRatio: Double,
    val voltage: Voltage
)

/** Хелпер-VM, чтобы получить UC через Hilt прямо из @Composable. */
@HiltViewModel
class DevicePickerHelperVm @Inject constructor(
    private val addDevicesToRoomUseCase: AddDevicesToRoomUseCase
) : androidx.lifecycle.ViewModel() {
    suspend fun add(roomId: Long, reqs: List<DeviceCreateRequest>): List<Long> {
        return addDevicesToRoomUseCase(roomId, reqs)
    }
}

/** Преобразование текстовых вводов в батч DeviceCreateRequest. */
private fun buildRequests(
    defaults: List<DefaultDevice>,
    qtyMap: Map<Long, Int>,
    nameOverride: Map<Long, String>,
    powerOverride: Map<Long, String>,
    unitOverride: Map<Long, PowerUnit>
): List<DeviceCreateRequest> {
    val byId = defaults.associateBy { it.id }
    val out = mutableListOf<DeviceCreateRequest>()
    for ((id, count) in qtyMap) {
        if (count <= 0) continue
        val def = byId[id] ?: continue
        val title = (nameOverride[id] ?: def.name).trim().ifEmpty { def.name }
        val rawText = (powerOverride[id] ?: def.power.toString()).replace(',', '.')
        val raw = rawText.toDoubleOrNull()?.takeIf { it > 0.0 } ?: def.power.toDouble()
        val watts = when (unitOverride[id] ?: PowerUnit.W) {
            PowerUnit.W  -> raw.toInt()
            PowerUnit.kW -> (raw * 1000.0).toInt()
        }.coerceAtLeast(1)
        out += DeviceCreateRequest(
            title = title,
            type = def.deviceType,
            count = count,
            ratedPowerW = watts,
            powerFactor = def.powerFactor,
            demandRatio = def.demandRatio,
            voltage = def.voltage
        )
    }
    return out
}

/** Утилита показа напряжения (оставь свою реализацию, если уже есть). */
private fun ru.mugalimov.volthome.domain.model.VoltageType.toReadableLabel(): String = when (this) {
    VoltageType.AC_1PHASE -> "220 В"
    VoltageType.AC_3PHASE -> "380 В"
    VoltageType.DC -> "DC"
}