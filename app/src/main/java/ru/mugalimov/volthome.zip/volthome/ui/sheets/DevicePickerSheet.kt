package ru.mugalimov.volthome.ui.sheets

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.relocation.BringIntoViewRequester
import androidx.compose.foundation.relocation.bringIntoViewRequester
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import ru.mugalimov.volthome.core.validation.InputConstraints
import ru.mugalimov.volthome.domain.model.DefaultDevice
import ru.mugalimov.volthome.domain.model.DeviceType
import ru.mugalimov.volthome.domain.model.ProFeature
import ru.mugalimov.volthome.domain.model.Voltage
import ru.mugalimov.volthome.domain.model.VoltageType
import ru.mugalimov.volthome.domain.model.create.DeviceCreateRequest as DomainDeviceCreateRequest
import ru.mugalimov.volthome.domain.use_case.AddDevicesToRoomUseCase
import ru.mugalimov.volthome.ui.components.device.adapter.DeviceParamsDraft
import ru.mugalimov.volthome.ui.components.device.adapter.DeviceParamsValidator
import ru.mugalimov.volthome.ui.model.LocalUserPlan
import ru.mugalimov.volthome.ui.paywall.PaywallBus
import javax.inject.Inject

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DevicePickerSheet(
    roomId: Long,
    defaultDevices: List<DefaultDevice>,
    onDismiss: () -> Unit,
    onAdded: (List<Long>) -> Unit,
    helperVm: DevicePickerHelperVm = hiltViewModel(),
    paywallBus: PaywallBus = hiltViewModel<DevicePickerSheetPaywallHolder>().paywallBus
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val scope = rememberCoroutineScope()

    val isPro = LocalUserPlan.current.isPro

    var search by remember { mutableStateOf("") }

    val qty = remember { mutableStateMapOf<Long, Int>() }
    val expandedMap = remember { mutableStateMapOf<Long, Boolean>() }
    val nameOverride = remember { mutableStateMapOf<Long, String>() }
    val powerOverride = remember { mutableStateMapOf<Long, String>() }
    val powerErrors = remember { mutableStateMapOf<Long, String?>() }

    // ✅ Advanced overrides (только PRO применяет)
    val pfOverride = remember { mutableStateMapOf<Long, String>() }
    val drOverride = remember { mutableStateMapOf<Long, String>() }
    val voltageOverride = remember { mutableStateMapOf<Long, Voltage>() }

    // ✅ новые: deviceType + flags
    val deviceTypeOverride = remember { mutableStateMapOf<Long, DeviceType>() }
    val hasMotorOverride = remember { mutableStateMapOf<Long, Boolean>() }
    val requiresDedicatedOverride = remember { mutableStateMapOf<Long, Boolean>() }
    val requiresSocketOverride = remember { mutableStateMapOf<Long, Boolean>() }

    val bringIntoViewRequester = remember { BringIntoViewRequester() }

    val filtered = remember(search, defaultDevices) {
        val q = search.trim().lowercase()
        if (q.isEmpty()) defaultDevices else defaultDevices.filter {
            it.name.lowercase().contains(q)
        }
    }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        dragHandle = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 6.dp, bottom = 4.dp)
            ) {
                BottomSheetDefaults.DragHandle()
                Spacer(Modifier.height(6.dp))
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp)
                ) {
                    Text(text = "Добавить устройства")
                    val totalTop = qty.values.sum()
                    val hasErrorsTop = powerErrors.values.any { it != null }
                    IconButton(
                        onClick = {
                            scope.launch {
                                val reqs = buildRequestsForPicker(
                                    defaults = defaultDevices,
                                    qtyMap = qty,
                                    nameOverride = nameOverride,
                                    powerOverride = powerOverride,
                                    isPro = isPro,
                                    pfOverride = pfOverride,
                                    drOverride = drOverride,
                                    voltageOverride = voltageOverride,
                                    deviceTypeOverride = deviceTypeOverride,
                                    hasMotorOverride = hasMotorOverride,
                                    requiresDedicatedOverride = requiresDedicatedOverride,
                                    requiresSocketOverride = requiresSocketOverride
                                )
                                if (reqs.isEmpty()) {
                                    onDismiss(); return@launch
                                }
                                val ids = helperVm.add(roomId, reqs)
                                onAdded(ids)
                                onDismiss()
                            }
                        },
                        enabled = totalTop > 0 && !hasErrorsTop
                    ) { Icon(Icons.Rounded.Check, contentDescription = "Добавить") }
                }
            }
        }
    ) {
        Column(
            Modifier
                .padding(horizontal = 16.dp, vertical = 8.dp)
                .bringIntoViewRequester(bringIntoViewRequester)
                .imePadding()
        ) {
            OutlinedTextField(
                value = search,
                onValueChange = { search = it },
                modifier = Modifier
                    .fillMaxWidth(0.95f)
                    .onFocusChanged {
                        if (it.isFocused) scope.launch { delay(150); bringIntoViewRequester.bringIntoView() }
                    },
                singleLine = true,
                placeholder = { Text("Поиск устройства…") }
            )

            Spacer(Modifier.height(8.dp))

            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(10.dp),
                contentPadding = PaddingValues(bottom = 96.dp)
            ) {
                items(filtered, key = { it.id }) { def ->
                    val expanded = expandedMap[def.id] == true
                    val count = qty[def.id] ?: 0

                    val type = deviceTypeOverride[def.id] ?: def.deviceType
                    val volt = voltageOverride[def.id] ?: def.voltage

                    val hasMotor = hasMotorOverride[def.id] ?: def.hasMotor
                    val reqDedicated =
                        requiresDedicatedOverride[def.id] ?: def.requiresDedicatedCircuit
                    val reqSocket = requiresSocketOverride[def.id] ?: def.requiresSocketConnection

                    Card {
                        Column(Modifier.padding(12.dp)) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(Modifier.weight(1f)) {
                                    Text(def.name)
                                    Text("${def.power} Вт")
                                }
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    IconButton(onClick = {
                                        qty[def.id] = (count - 1).coerceAtLeast(0)
                                    }) {
                                        Icon(Icons.Rounded.Remove, contentDescription = "Уменьшить")
                                    }

                                    Box(
                                        Modifier.width(28.dp),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(text = count.toString(), textAlign = TextAlign.Center)
                                    }

                                    IconButton(onClick = {
                                        qty[def.id] = (count + 1).coerceAtMost(99)
                                    }) {
                                        Icon(Icons.Rounded.Add, contentDescription = "Увеличить")
                                    }

                                    IconButton(onClick = {
                                        expandedMap[def.id] = !(expandedMap[def.id] ?: false)
                                    }) {
                                        Icon(
                                            if (expanded) Icons.Rounded.ExpandLess else Icons.Rounded.ExpandMore,
                                            contentDescription = null
                                        )
                                    }
                                }
                            }

                            AnimatedVisibility(expanded) {
                                Column {
                                    Spacer(Modifier.height(10.dp))

                                    // FREE: имя редактируется
                                    OutlinedTextField(
                                        value = nameOverride[def.id] ?: def.name,
                                        onValueChange = { nameOverride[def.id] = it },
                                        label = { Text("Название") },
                                        singleLine = true,
                                        shape = RoundedCornerShape(12.dp),
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .heightIn(min = 56.dp)
                                            .onFocusChanged {
                                                if (it.isFocused) scope.launch { delay(150); bringIntoViewRequester.bringIntoView() }
                                            }
                                    )

                                    Spacer(Modifier.height(10.dp))

                                    Column(
                                        modifier = Modifier.fillMaxWidth(),
                                        verticalArrangement = Arrangement.spacedBy(10.dp)
                                    ) {
                                        // Ряд 1: Мощность | Тип устройства (dropdown)
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.spacedBy(12.dp),
                                            verticalAlignment = Alignment.Top
                                        ) {
                                            val currentPowerText =
                                                powerOverride[def.id] ?: def.power.toString()
                                            val error = powerErrors[def.id]

                                            OutlinedTextField(
                                                value = currentPowerText,
                                                onValueChange = { new ->
                                                    val cleaned =
                                                        DeviceParamsValidator.normalizePowerText(new)
                                                    powerOverride[def.id] = cleaned
                                                    val errs = DeviceParamsValidator.validate(
                                                        DeviceParamsDraft(
                                                            name = nameOverride[def.id] ?: def.name,
                                                            powerText = cleaned,
                                                            deviceType = deviceTypeOverride[def.id]
                                                                ?: def.deviceType,
                                                            powerFactorText = pfOverride[def.id]
                                                                ?: def.powerFactor.toString(),
                                                            demandRatioText = drOverride[def.id]
                                                                ?: def.demandRatio.toString(),
                                                            voltageType = (voltageOverride[def.id]
                                                                ?: def.voltage).type,
                                                            hasMotor = hasMotorOverride[def.id]
                                                                ?: def.hasMotor,
                                                            requiresDedicatedCircuit = requiresDedicatedOverride[def.id]
                                                                ?: def.requiresDedicatedCircuit,
                                                            requiresSocketConnection = requiresSocketOverride[def.id]
                                                                ?: def.requiresSocketConnection
                                                        )
                                                    )
                                                    powerErrors[def.id] = errs.powerError
                                                },
                                                label = { Text("Мощность (Вт)") },
                                                singleLine = true,
                                                isError = error != null,
                                                supportingText = {
                                                    Text(
                                                        error
                                                            ?: "Мощность должна быть в допустимых пределах"
                                                    )
                                                },
                                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                                                shape = RoundedCornerShape(12.dp),
                                                modifier = Modifier
                                                    .weight(1f)
                                                    .heightIn(min = 56.dp)
                                                    .onFocusChanged {
                                                        if (it.isFocused) scope.launch { delay(150); bringIntoViewRequester.bringIntoView() }
                                                    }
                                            )

                                            EnumDropdownField(
                                                label = "Тип устройства",
                                                value = type,
                                                values = DeviceType.values().toList(),
                                                valueLabel = { it.name },
                                                locked = !isPro,
                                                onLockedClick = { paywallBus.request(ProFeature.ADVANCED_DEVICE_EDITOR) },
                                                onValueChange = { deviceTypeOverride[def.id] = it },
                                                modifier = Modifier.weight(1f)
                                            )
                                        }

                                        // Ряд 2: PF | Кс (PRO) — поля без диалогов
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                                        ) {
                                            val pfText =
                                                pfOverride[def.id] ?: def.powerFactor.toString()
                                            val drText =
                                                drOverride[def.id] ?: def.demandRatio.toString()

                                            LockedDecimalField(
                                                label = "Коэфф. мощности (PF)",
                                                value = pfText,
                                                locked = !isPro,
                                                hint = "Влияет на расчёт тока",
                                                error = validateRatio(pfText),
                                                onLockedClick = { paywallBus.request(ProFeature.ADVANCED_DEVICE_EDITOR) },
                                                onValueChange = {
                                                    pfOverride[def.id] = it.trim().replace(',', '.')
                                                },
                                                modifier = Modifier.weight(1f),
                                                bringIntoViewRequester = bringIntoViewRequester,
                                                scope = scope
                                            )

                                            LockedDecimalField(
                                                label = "Коэфф. спроса",
                                                value = drText,
                                                locked = !isPro,
                                                hint = "Учитывает реальную нагрузку",
                                                error = validateRatio(drText),
                                                onLockedClick = { paywallBus.request(ProFeature.ADVANCED_DEVICE_EDITOR) },
                                                onValueChange = {
                                                    drOverride[def.id] = it.trim().replace(',', '.')
                                                },
                                                modifier = Modifier.weight(1f),
                                                bringIntoViewRequester = bringIntoViewRequester,
                                                scope = scope
                                            )
                                        }

                                        // Ряд 3: Напряжение (dropdown), DC disabled
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                                        ) {
                                            VoltageTypeDropdownField(
                                                label = "Напряжение",
                                                value = volt.type,
                                                locked = !isPro,
                                                onLockedClick = { paywallBus.request(ProFeature.ADVANCED_DEVICE_EDITOR) },
                                                onValueChange = { vt ->
                                                    voltageOverride[def.id] = when (vt) {
                                                        VoltageType.AC_1PHASE -> Voltage(
                                                            220,
                                                            VoltageType.AC_1PHASE
                                                        )

                                                        VoltageType.AC_3PHASE -> Voltage(
                                                            380,
                                                            VoltageType.AC_3PHASE
                                                        )

                                                        VoltageType.DC -> volt
                                                    }
                                                },
                                                modifier = Modifier.weight(1f)
                                            )
                                            Spacer(Modifier.weight(1f))
                                        }

                                        // Ряд 4: flags (PRO)
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                                        ) {
                                            YesNoDropdownField(
                                                label = "Есть двигатель",
                                                value = hasMotor,
                                                locked = !isPro,
                                                onLockedClick = { paywallBus.request(ProFeature.ADVANCED_DEVICE_EDITOR) },
                                                onValueChange = { hasMotorOverride[def.id] = it },
                                                modifier = Modifier.weight(1f)
                                            )
                                            YesNoDropdownField(
                                                label = "Выделенная линия",
                                                value = reqDedicated,
                                                locked = !isPro,
                                                onLockedClick = { paywallBus.request(ProFeature.ADVANCED_DEVICE_EDITOR) },
                                                onValueChange = {
                                                    requiresDedicatedOverride[def.id] = it
                                                },
                                                modifier = Modifier.weight(1f)
                                            )
                                        }

                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                                        ) {
                                            YesNoDropdownField(
                                                label = "Подключение розеткой",
                                                value = reqSocket,
                                                locked = !isPro,
                                                onLockedClick = { paywallBus.request(ProFeature.ADVANCED_DEVICE_EDITOR) },
                                                onValueChange = {
                                                    requiresSocketOverride[def.id] = it
                                                },
                                                modifier = Modifier.weight(1f)
                                            )
                                            Spacer(Modifier.weight(1f))
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            Spacer(Modifier.height(8.dp))
            val total = qty.values.sum()
            val hasErrorsBottom = powerErrors.values.any { it != null }

            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Button(
                    enabled = total > 0 && !hasErrorsBottom,
                    onClick = {
                        scope.launch {
                            val reqs = buildRequestsForPicker(
                                defaults = defaultDevices,
                                qtyMap = qty,
                                nameOverride = nameOverride,
                                powerOverride = powerOverride,
                                isPro = isPro,
                                pfOverride = pfOverride,
                                drOverride = drOverride,
                                voltageOverride = voltageOverride,
                                deviceTypeOverride = deviceTypeOverride,
                                hasMotorOverride = hasMotorOverride,
                                requiresDedicatedOverride = requiresDedicatedOverride,
                                requiresSocketOverride = requiresSocketOverride
                            )
                            if (reqs.isEmpty()) {
                                onDismiss(); return@launch
                            }
                            val ids = helperVm.add(roomId, reqs)
                            onAdded(ids)
                            onDismiss()
                        }
                    }
                ) { Icon(Icons.Rounded.Check, contentDescription = "Добавить") }

                Button(onClick = onDismiss) { Text("Отмена") }
            }

            Spacer(Modifier.height(12.dp))
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun <T> EnumDropdownField(
    label: String,
    value: T,
    values: List<T>,
    valueLabel: (T) -> String,
    locked: Boolean,
    onLockedClick: () -> Unit,
    onValueChange: (T) -> Unit,
    modifier: Modifier = Modifier
) {
    var expanded by remember { mutableStateOf(false) }

    val open = {
        if (locked) onLockedClick() else expanded = true
    }

    ExposedDropdownMenuBox(
        expanded = expanded,
        onExpandedChange = { open() },
        modifier = modifier
            .fillMaxWidth()
            .heightIn(min = 56.dp)
    ) {
        OutlinedTextField(
            value = valueLabel(value),
            onValueChange = {},
            readOnly = true,
            enabled = true,
            singleLine = true,
            label = { Text(label) },
            trailingIcon = {
                if (locked) Icon(Icons.Rounded.Lock, contentDescription = null)
                else ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded)
            },
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier
                .menuAnchor()
                .fillMaxWidth()
        )

        ExposedDropdownMenu(
            expanded = expanded,
            onDismissRequest = { expanded = false }
        ) {
            values.forEach { item ->
                DropdownMenuItem(
                    text = { Text(valueLabel(item)) },
                    onClick = {
                        expanded = false
                        onValueChange(item)
                    }
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun VoltageTypeDropdownField(
    label: String,
    value: VoltageType,
    locked: Boolean,
    onLockedClick: () -> Unit,
    onValueChange: (VoltageType) -> Unit,
    modifier: Modifier = Modifier
) {
    var expanded by remember { mutableStateOf(false) }

    val open = {
        if (locked) onLockedClick() else expanded = true
    }

    ExposedDropdownMenuBox(
        expanded = expanded,
        onExpandedChange = { open() },
        modifier = modifier
            .fillMaxWidth()
            .heightIn(min = 56.dp)
    ) {
        OutlinedTextField(
            value = when (value) {
                VoltageType.AC_1PHASE -> "AC 1ф (220 В)"
                VoltageType.AC_3PHASE -> "AC 3ф (380 В)"
                VoltageType.DC -> "DC"
            },
            onValueChange = {},
            readOnly = true,
            enabled = true,
            singleLine = true,
            label = { Text(label) },
            supportingText = { Text("DC пока недоступен") },
            trailingIcon = {
                if (locked) Icon(Icons.Rounded.Lock, contentDescription = null)
                else ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded)
            },
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier
                .menuAnchor()
                .fillMaxWidth()
        )

        ExposedDropdownMenu(
            expanded = expanded,
            onDismissRequest = { expanded = false }
        ) {
            DropdownMenuItem(
                text = { Text("AC 1ф (220 В)") },
                onClick = { expanded = false; onValueChange(VoltageType.AC_1PHASE) }
            )
            DropdownMenuItem(
                text = { Text("AC 3ф (380 В)") },
                onClick = { expanded = false; onValueChange(VoltageType.AC_3PHASE) }
            )
            DropdownMenuItem(
                enabled = false,
                text = { Text("DC — скоро") },
                onClick = {}
            )
        }
    }
}

@Composable
private fun YesNoDropdownField(
    label: String,
    value: Boolean,
    locked: Boolean,
    onLockedClick: () -> Unit,
    onValueChange: (Boolean) -> Unit,
    modifier: Modifier = Modifier
) {
    EnumDropdownField(
        label = label,
        value = value,
        values = listOf(true, false),
        valueLabel = { if (it) "Да" else "Нет" },
        locked = locked,
        onLockedClick = onLockedClick,
        onValueChange = onValueChange,
        modifier = modifier
    )
}

@Composable
private fun LockedDecimalField(
    label: String,
    value: String,
    locked: Boolean,
    hint: String?,
    error: String?,
    onLockedClick: () -> Unit,
    onValueChange: (String) -> Unit,
    modifier: Modifier,
    bringIntoViewRequester: BringIntoViewRequester,
    scope: CoroutineScope
) {
    val m = modifier
        .fillMaxWidth()
        .heightIn(min = 56.dp)
        .let { base -> if (locked) base.clickable { onLockedClick() } else base }

    OutlinedTextField(
        value = value,
        onValueChange = { if (!locked) onValueChange(it) },
        label = { Text(label) },
        enabled = true,
        readOnly = locked,
        singleLine = true,
        isError = (error != null && !locked),
        supportingText = {
            when {
                locked && hint != null -> Text(hint)
                !locked && error != null -> Text(error)
                hint != null -> Text(hint)
            }
        },
        trailingIcon = { if (locked) Icon(Icons.Rounded.Lock, contentDescription = null) },
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
        shape = RoundedCornerShape(12.dp),
        modifier = m.onFocusChanged {
            if (it.isFocused) scope.launch {
                delay(150)
                bringIntoViewRequester.bringIntoView()
            }
        }
    )
}

@HiltViewModel
class DevicePickerSheetPaywallHolder @Inject constructor(
    val paywallBus: PaywallBus
) : androidx.lifecycle.ViewModel()

@HiltViewModel
class DevicePickerHelperVm @Inject constructor(
    private val addDevicesToRoomUseCase: AddDevicesToRoomUseCase
) : androidx.lifecycle.ViewModel() {
    suspend fun add(roomId: Long, reqs: List<DomainDeviceCreateRequest>): List<Long> {
        return addDevicesToRoomUseCase(roomId, reqs)
    }
}

private fun buildRequestsForPicker(
    defaults: List<DefaultDevice>,
    qtyMap: Map<Long, Int>,
    nameOverride: Map<Long, String>,
    powerOverride: Map<Long, String>,
    isPro: Boolean,
    pfOverride: Map<Long, String>,
    drOverride: Map<Long, String>,
    voltageOverride: Map<Long, Voltage>,
    deviceTypeOverride: Map<Long, DeviceType>,
    hasMotorOverride: Map<Long, Boolean>,
    requiresDedicatedOverride: Map<Long, Boolean>,
    requiresSocketOverride: Map<Long, Boolean>
): List<DomainDeviceCreateRequest> {
    val byId = defaults.associateBy { it.id }
    val out = mutableListOf<DomainDeviceCreateRequest>()

    for ((id, count) in qtyMap) {
        if (count <= 0) continue
        val def = byId[id] ?: continue

        val title = (nameOverride[id] ?: def.name).trim().ifEmpty { def.name }
        val cleaned =
            DeviceParamsValidator.normalizePowerText(powerOverride[id] ?: def.power.toString())
        val raw = cleaned.toDoubleOrNull()?.takeIf { it > 0.0 } ?: def.power.toDouble()
        val watts = raw.toInt().coerceAtLeast(1)

        val pf = if (isPro) pfOverride[id]?.trim()?.replace(',', '.')?.toDoubleOrNull() else null
        val dr = if (isPro) drOverride[id]?.trim()?.replace(',', '.')?.toDoubleOrNull() else null

        val type = if (isPro) (deviceTypeOverride[id] ?: def.deviceType) else def.deviceType
        val volt = if (isPro) (voltageOverride[id] ?: def.voltage) else def.voltage

        val hm = if (isPro) hasMotorOverride[id] else null
        val rd = if (isPro) requiresDedicatedOverride[id] else null
        val rs = if (isPro) requiresSocketOverride[id] else null

        out += DomainDeviceCreateRequest(
            title = title,
            type = type,
            count = count,
            ratedPowerW = watts,
            powerFactor = pf ?: def.powerFactor,
            demandRatio = dr ?: def.demandRatio,
            voltage = volt,
            hasMotor = hm ?: def.hasMotor,
            requiresDedicatedCircuit = rd ?: def.requiresDedicatedCircuit,
            requiresSocketConnection = rs ?: def.requiresSocketConnection
        )
    }
    return out
}

private fun validateRatio(input: String): String? {
    val v = input.trim().replace(',', '.').toDoubleOrNull()
    if (v == null) return "Введите число"
    if (v < 0.1 || v > 1.0) return "Допустимо 0.1 — 1.0"
    return null
}