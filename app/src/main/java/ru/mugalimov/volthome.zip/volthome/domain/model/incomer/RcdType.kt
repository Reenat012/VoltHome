package ru.mugalimov.volthome.domain.model.incomer

enum class RcdType { AC, A, F }