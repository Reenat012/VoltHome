package ru.mugalimov.volthome.application

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class VoltHomeApplication : Application()