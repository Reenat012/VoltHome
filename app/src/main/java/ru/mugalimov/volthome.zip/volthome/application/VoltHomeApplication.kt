package ru.mugalimov.volthome.application

import android.app.Application
import android.util.Log
import androidx.hilt.work.HiltWorkerFactory
import androidx.work.Configuration
import com.yandex.metrica.YandexMetrica
import com.yandex.metrica.YandexMetricaConfig
import dagger.hilt.android.HiltAndroidApp
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import ru.mugalimov.volthome.BuildConfig
import ru.mugalimov.volthome.Secret
import javax.inject.Inject

@HiltAndroidApp
class VoltHomeApp : Application(), Configuration.Provider {

    @Inject lateinit var workerFactory: HiltWorkerFactory

    private val appScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    @Volatile private var metricaCoreInited = false

    override val workManagerConfiguration: Configuration
        get() = Configuration.Builder()
            .setWorkerFactory(workerFactory)
            .setMinimumLoggingLevel(Log.DEBUG)
            .build()

    override fun onCreate() {
        super.onCreate()
        initMetricaCore()
    }

    /**
     * Инициализация ядра AppMetrica в фоне.
     * Собираем конфиг на Default, активируем SDK, затем на main включаем авто-трекинг.
     */
    private fun initMetricaCore() {
        if (metricaCoreInited) return
        metricaCoreInited = true

        appScope.launch {
            runCatching {
                val cfg = withContext(Dispatchers.Default) {
                    val builder = YandexMetricaConfig
                        .newConfigBuilder(Secret.APP_METRICA_API_KEY)
                    if (BuildConfig.DEBUG) builder.withLogs()
                    builder.build()
                }
                YandexMetrica.activate(applicationContext, cfg)
            }.onSuccess {
                withContext(Dispatchers.Main) {
                    YandexMetrica.enableActivityAutoTracking(this@VoltHomeApp)
                }
            }.onFailure {
                Log.w("VoltHomeApp", "AppMetrica core init failed: ${it.message}", it)
            }
        }
    }
}