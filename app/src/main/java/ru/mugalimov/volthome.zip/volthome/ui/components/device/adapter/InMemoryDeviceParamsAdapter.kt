package ru.mugalimov.volthome.ui.components.device.adapter

import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.remember
import ru.mugalimov.volthome.domain.model.DeviceType
import ru.mugalimov.volthome.domain.model.VoltageType
import ru.mugalimov.volthome.ui.components.device.adapter.DeviceParamsValidator.normalizeDecimal
import ru.mugalimov.volthome.ui.components.device.adapter.DeviceParamsValidator.normalizeName
import ru.mugalimov.volthome.ui.components.device.adapter.DeviceParamsValidator.validate

/**
 * Для AddRoomSheet / DevicePickerSheet.
 * Хранит drafts per key и отдаёт единый контракт в editor.
 *
 * ВАЖНО: этот класс нужно создавать через remember { ... } на уровне sheet,
 * чтобы stateMap жил весь lifecycle sheet.
 */
class InMemoryDeviceParamsAdapter<K>(
    override val isPro: Boolean,
    private val paywall: () -> Unit
) : DeviceParamsEditorAdapter<K> {

    private val drafts = mutableStateMapOf<K, DeviceParamsDraft>()

    override fun onLockedClick() = paywall()

    @Composable
    override fun state(key: K, seed: DeviceParamsDraft): DeviceParamsEditorState<K> {
        // фиксируем seed один раз per key
        val draft = remember(key) {
            drafts.getOrPut(key) { seed }
        }.also {
            // важно: если drafts уже заполнен, берём его
            // remember(key) выше мог вернуть устаревший ref — поэтому всегда читаем map
        }

        val current = drafts[key] ?: seed
        val errors = validate(current)

        fun update(block: (DeviceParamsDraft) -> DeviceParamsDraft) {
            drafts[key] = block(drafts[key] ?: seed)
        }

        return DeviceParamsEditorState(
            key = key,
            draft = current,
            errors = errors,

            onNameChange = { new ->
                update { it.copy(name = normalizeName(new)) }
            },
            onPowerTextChange = { new ->
                update { it.copy(powerText = normalizeDecimal(new)) }
            },

            onDeviceTypeChange = { new ->
                update { it.copy(deviceType = new) }
            },
            onPowerFactorTextChange = { new ->
                update { it.copy(powerFactorText = normalizeDecimal(new)) }
            },
            onDemandRatioTextChange = { new ->
                update { it.copy(demandRatioText = normalizeDecimal(new)) }
            },
            onVoltageTypeChange = { new ->
                update { it.copy(voltageType = new) }
            },

            onHasMotorChange = { v ->
                update { it.copy(hasMotor = v) }
            },
            onRequiresDedicatedCircuitChange = { v ->
                update { it.copy(requiresDedicatedCircuit = v) }
            },
            onRequiresSocketConnectionChange = { v ->
                update { it.copy(requiresSocketConnection = v) }
            }
        )
    }

    /**
     * Если нужно собрать итоговые данные для buildRequests:
     */
    fun snapshot(key: K, seed: DeviceParamsDraft): DeviceParamsDraft =
        drafts[key] ?: seed
}