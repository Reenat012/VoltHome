package ru.mugalimov.volthome

object Secret {
    // ⚠️ Не коммитим ключ в Git, кладём временно только локально
    const val APP_METRICA_API_KEY: String = "11e56729-86fe-4cc0-818d-68ff837db06f"
}